from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

# Цвета
ORANGE = RGBColor(0xFF, 0x8C, 0x00)
DARK = RGBColor(0x2D, 0x2D, 0x2D)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_BG = RGBColor(0xFF, 0xF5, 0xE6)

def set_slide_bg(slide, r, g, b):
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(r, g, b)

def add_text_box(slide, left, top, width, height, text, font_size=24, bold=False, color=DARK, alignment=PP_ALIGN.LEFT):
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.font.color.rgb = color
    p.alignment = alignment
    return txBox

def add_bullets(slide, left, top, width, height, items, font_size=20, color=DARK):
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = txBox.text_frame
    tf.word_wrap = True
    for i, item in enumerate(items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = item
        p.font.size = Pt(font_size)
        p.font.color.rgb = color
        p.space_after = Pt(12)
        p.level = 0
    return txBox

# Слайд 1 — Титульный
slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank
set_slide_bg(slide, 0xFF, 0x8C, 0x00)
add_text_box(slide, 1, 1.5, 11, 2, "🐱  КОТЫ", font_size=72, bold=True, color=WHITE, alignment=PP_ALIGN.CENTER)
add_text_box(slide, 1, 3.5, 11, 1.5, "Лучшие друзья человека", font_size=36, color=WHITE, alignment=PP_ALIGN.CENTER)
add_text_box(slide, 1, 5.5, 11, 1, "🐾  🐾  🐾  🐾  🐾", font_size=36, color=WHITE, alignment=PP_ALIGN.CENTER)

# Слайд 2 — Интересные факты
slide = prs.slides.add_slide(prs.slide_layouts[6])
set_slide_bg(slide, 0xFF, 0xF5, 0xE6)
add_text_box(slide, 0.5, 0.5, 12, 1.2, "🔍 Интересные факты о котах", font_size=40, bold=True, color=ORANGE, alignment=PP_ALIGN.CENTER)
facts = [
    "😴  Коты проводят 70% своей жизни во сне",
    "👃  У каждого кота уникальный рисунок носа — как отпечаток пальца",
    "🔊  Коты могут издавать более 100 различных звуков",
    "🏆  Самый старый кот прожил 38 лет",
    "🏃  Коты бегают со скоростью до 48 км/ч",
    "❤️  Коты мурлыкают на частоте 25-150 Гц — это помогает заживлению тканей",
]
add_bullets(slide, 1.5, 2, 10, 5, facts, font_size=24, color=DARK)

# Слайд 3 — Популярные породы
slide = prs.slides.add_slide(prs.slide_layouts[6])
set_slide_bg(slide, 0xFF, 0xF5, 0xE6)
add_text_box(slide, 0.5, 0.5, 12, 1.2, "🐈 Популярные породы", font_size=40, bold=True, color=ORANGE, alignment=PP_ALIGN.CENTER)
breeds = [
    "🦁  Мейн-кун — гигант среди домашних котов (до 12 кг!)",
    "👻  Сфинкс — бесшёрстная, но очень ласковая порода",
    "🇬🇧  Британская короткошёрстная — классика жанра",
    "🦄  Шотландская вислоухая — с милыми загнутыми ушами",
    "🇹🇭  Сиамская — умная и голосистая порода",
    "👑  Персидская — царственная красота и спокойный характер",
]
add_bullets(slide, 1.5, 2, 10, 5, breeds, font_size=24, color=DARK)

# Слайд 4 — Польза для здоровья
slide = prs.slides.add_slide(prs.slide_layouts[6])
set_slide_bg(slide, 0xFF, 0xF5, 0xE6)
add_text_box(slide, 0.5, 0.5, 12, 1.2, "💚 Польза котов для здоровья", font_size=40, bold=True, color=ORANGE, alignment=PP_ALIGN.CENTER)
health = [
    "😌  Снижают уровень стресса и тревожности",
    "🎵  Мурлыкание помогает заживлять кости и ткани",
    "💊  Понижают давление и уровень холестерина",
    "🫀  Уменьшают риск инфаркта на 40%",
    "🤗  Помогают бороться с одиночеством",
    "👶  Дети, растущие с котами, реже болеют аллергией",
]
add_bullets(slide, 1.5, 2, 10, 5, health, font_size=24, color=DARK)

# Слайд 5 — Коты в культуре
slide = prs.slides.add_slide(prs.slide_layouts[6])
set_slide_bg(slide, 0xFF, 0xF5, 0xE6)
add_text_box(slide, 0.5, 0.5, 12, 1.2, "🌍 Коты в культуре", font_size=40, bold=True, color=ORANGE, alignment=PP_ALIGN.CENTER)
culture = [
    "🏛️  В Древнем Египте котов боготворили и мумифицировали",
    "📱  Интернет-мемы сделали котов самыми популярными животными онлайн",
    "🎨  Сальвадор Дали был известным любителем котов",
    "🇯🇵  В Японии манэки-нэко (кот-привет) приносит удачу",
    "🐈  Кот Боб — знаменитый рыжий уличный кот из Лондона",
    "📚  Кошка Бегемот из «Мастера и Маргариты» — один из самых известных котов в литературе",
]
add_bullets(slide, 1.5, 2, 10, 5, culture, font_size=24, color=DARK)

# Слайд 6 — Заключительный
slide = prs.slides.add_slide(prs.slide_layouts[6])
set_slide_bg(slide, 0xFF, 0x8C, 0x00)
add_text_box(slide, 1, 2, 11, 2, "Спасибо за внимание!", font_size=60, bold=True, color=WHITE, alignment=PP_ALIGN.CENTER)
add_text_box(slide, 1, 4.2, 11, 1.5, "🐾  Возьмите кота — и ваша жизнь станет ярче!  🐾", font_size=28, color=WHITE, alignment=PP_ALIGN.CENTER)

output = r"C:\Users\user\Desktop\cats.pptx"
prs.save(output)
print(f"Презентация сохранена: {output}")
