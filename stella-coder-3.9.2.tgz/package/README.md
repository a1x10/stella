# Stella Coder 3.9

> AI coding agent with computer control, smart home, Office automation, and antivirus — all in your terminal.

## Features

- **AI Agent** — Read, create, edit files; run shell commands; search code
- **100+ commands** — `/help`, `/model`, `/plan`, `/commit`, `/exec`, `/open`, `/tv`, `/docker`, etc.
- **20+ AI models** — Free defaults (MiMo, DeepSeek), plus GPT, Claude, Gemini
- **Computer control** — Screenshot, volume, brightness, WiFi, notifications
- **Server management** — SSH, Docker, PM2, ports, firewall
- **Smart home** — Sony TV, HDMI-CEC, Yeelight, Chromecast, Wake-on-LAN
- **Office automation** — PowerPoint, Word, Excel via COM
- **Application control** — Focus windows, type text, hotkeys, screenshots
- **Antivirus** — Built-in scanner with 100+ signatures

## Quick Install

### From npm (recommended)

```bash
npm install -g stella-coder
stella
```

### From source

```bash
git clone https://github.com/codex-alex/stella-coder.git
cd stella-coder
npm install
npm link
stella
```

### Windows one-click

Download `install.bat` and run it.

## Usage

```bash
stella                    # Interactive REPL
stella -p "fix bug in utils.ts"  # One-shot command
```

### Key Commands

| Command | Description |
|---------|-------------|
| `/help` | Show all commands |
| `/model` | Select AI model |
| `/plan` | Execute multi-step tasks |
| `/exec <cmd>` | Run shell command |
| `/open <app>` | Open application |
| `/tv discover` | Find Sony TV |
| `/docker ps` | List containers |
| `/av` | Launch antivirus |

## Configuration

First run creates `~/.stella/config.json` with your API key and preferences.

**Free models work without API key** — just install [Ollama](https://ollama.com/download).

## License

MIT

---

**Stella Coder 3.9** · powered by codex alex
